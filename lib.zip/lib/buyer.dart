import 'package:flutter/material.dart';

class sellersecond extends StatefulWidget {
  const sellersecond({super.key});

  @override
  State<sellersecond> createState() => _sellersecondState();
}

class _sellersecondState extends State<sellersecond> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
    );
  }
}